// Minimal service worker — improves installability.
// You can expand this to add offline caching if needed.
self.addEventListener("install", (event) => {
  self.skipWaiting();
});
self.addEventListener("activate", (event) => {
  self.clients.claim();
});
