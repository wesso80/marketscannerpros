# Store Pack for Market Scanner

This folder contains the minimal files you need to make your web app store-ready.

## Files
- `/manifest.webmanifest` — PWA manifest (link in your HTML head with `<link rel="manifest" href="/manifest.webmanifest">`).
- `/sw.js` — minimal service worker (register in your HTML).
- `/privacy.html` — public privacy policy (link from your footer and use this URL in Play/App Store).
- `/.well-known/assetlinks.json` — for Android TWA (Bubblewrap). Must include your signing cert SHA-256 fingerprint.
- `/icons/icon-192.png`, `/icons/icon-512.png` — store/PWA icons.

## Where to host
Place these at the root of your site (Replit project):
- `manifest.webmanifest` -> `/`
- `sw.js` -> `/`
- `privacy.html` -> `/privacy.html`
- `.well-known/assetlinks.json` -> `/.well-known/assetlinks.json`
- `icons/` folder at `/icons`

## Bubblewrap (Android TWA) quick steps
1. Install: `npm i -g @bubblewrap/cli`
2. Init from manifest: `bubblewrap init --manifest=https://market-scanner-1-wesso80.replit.app/manifest.webmanifest` (App ID: com.wesso80.marketscanner)
3. Build bundle: `bubblewrap build-bundle` -> upload `.aab` to Play Console.
4. Serve `/.well-known/assetlinks.json` with the correct SHA-256 fingerprint from your signing key.
   - Get fingerprint: `keytool -list -v -keystore my-release-key.jks` (copy the SHA-256)
   - Replace it in `assetlinks.json` and redeploy.

## iOS (Capacitor) quick steps
- In `capacitor.config.ts` set:
  ```ts
  server: { url: "https://market-scanner-1-wesso80.replit.app", cleartext: false }
  ```
- `npx cap add ios && npx cap sync && npx cap open ios`
- Archive in Xcode and submit via App Store Connect.

