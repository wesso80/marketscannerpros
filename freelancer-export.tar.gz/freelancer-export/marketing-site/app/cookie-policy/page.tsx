export { default, metadata } from "../legal/cookie-policy/page";
