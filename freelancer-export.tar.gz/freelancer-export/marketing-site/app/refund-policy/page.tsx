export { default, metadata } from "../legal/refund-policy/page";
