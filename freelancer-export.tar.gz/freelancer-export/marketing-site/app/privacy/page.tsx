export { default, metadata } from "../legal/privacy/page";
