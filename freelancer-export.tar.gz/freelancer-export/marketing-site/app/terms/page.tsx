export { default, metadata } from "../legal/terms/page";
