export const APP_URL =
  process.env.NEXT_PUBLIC_APP_URL || 'https://app.marketscannerpros.app';
